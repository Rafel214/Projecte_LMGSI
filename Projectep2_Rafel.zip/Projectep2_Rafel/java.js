document.querySelectorAll('.heart').forEach(item => {
  item.addEventListener('click', function() {
      if (item.src.includes('heart.svg')) {
          item.src = './images/heart-fill.svg';
      } else {
          item.src = './images/heart.svg';
      }
  });
});

document.getElementById('arrow-up').addEventListener('click', function() {
  window.location.href = '#'; // Cambia '#' por la URL a la que deseas redirigir, si es necesario
});

const btnMenu = document.querySelector
("#btn-menu");
const navHeader = document.querySelector
("#nav-header");
const btnClose = document.querySelector
("#btn-close");

btnMenu.addEventListener("click", () => {
  navHeader.classList.remove('btn-menu'); 
  navHeader.classList.add('nav-visible');
  
});

btnClose.addEventListener("click", () => {
  navHeader.classList.remove('nav-visible');
  navHeader.classList.add("btn-menu");
});



